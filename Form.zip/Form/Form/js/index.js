CKEDITOR.replace( 'editor1' );

CKEDITOR.replace( 'editor2' );

CKEDITOR.replace( 'editor3' );